<?php

$jsdata = '';
foreach ($items as $key => $rows) {
  
  echo "<pre>";
  print_r($rows);
//  $nids = $rows->nid;
//  print $nids; 
//  /watchdog('rows', "<pre>".   print_r($rows, true)  . '</pre>');
//dpm($rows);
  $title = $rows->_field_data['nid']['entity']->title;
  $nid = $rows->_field_data['nid']['entity']->nid;
  $body = $rows->_field_data['nid']['entity']->body[$rows->_field_data['nid']['entity']->language][0]['value'];
  $image = $rows->_field_data['nid']['entity']->field_image[$rows->_field_data['nid']['entity']->language][0]['uri'];

  $newval[$key]['title'] = $title;
  if (isset($body)) {
    $newval[$key]['body'] = $body;
  }
  $newval[$key]['nid'] = $nid;

  $path = $imagepath = file_create_url($image);
  $jsdata .= "{image: '" . $path . "', link_rel: 'prettyPhoto'}";
}
?>

<script type="text/javascript">
  jQuery(document).ready(function () {
    var image_array = new Array();
    image_array = [<?php echo $jsdata; ?>];
    jQuery('#slider1').content_slider({
      map: image_array,
      max_shown_items: 7,
      responsive_by_available_space: 1,
      hv_switch: 0,
      active_item: 4,
      middle_click: 1,
      border_radius: 0,
      mode: 2,
      dinamically_set_position_class: 1,
      border_on_off: 0
    });
  });

</script>





<div class="content_slider_wrapper" id="slider1">
  <?php foreach ($newval as $key => $val): ?>
    <div class="circle_slider_text_wrapper" id="<?php print 'sw' . $key; ?>" style="display: none;">
      <div class="content_slider_text_block_wrap">
       <h3><?php echo l($val['title'], "node/" . $val['nid'], array('attributes' => array('class' => array('attorney-slider', 'attorney-title')))); ?></h3>
        <div>
         <?php
          if (isset($val['body'])) {
            print substr(strip_tags($val['body']), 0, 200);
            if (strlen($val['body']) > 200) 
            {
              print '....';
            }
          }
         ?></div>
        <?php echo l('Learn More', "node/" . $val['nid'], array('attributes' => array('class' => 'button_regular'), 'html' => true)); ?>
      </div>
    </div>
  <?php endforeach; ?>
</div>